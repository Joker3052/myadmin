const Test=()=>
{
    return(
        <>
        <header>
        <h1>Welcome to Our Clothing Store</h1>
        <p>Your one-stop destination for fashionable clothing.</p>
    </header>

    <nav>
        <ul>
            <li><a href="#">Home</a></li>
            <li><a href="#">Men s Clothing</a></li>
            <li><a href="#">Women s Clothing</a></li>
            <li><a href="#">Kids Clothing</a></li>
            <li><a href="#">Contact Us</a></li>
        </ul>
    </nav>
        </>
    )
}
export default Test;